<?php
/**
 * acf-ws-legal-update.php
 *
 * Registers ACF Pro fields for the `ws-legal-update` CPT.
 *
 * PURPOSE
 * -------
 * Provides structured metadata for Legal Update records, capturing
 * the nature, source, date, and affected jurisdictions of each
 * significant development in whistleblower law.
 *
 * Legal Updates are linked to one or more Jurisdiction records
 * through the ws_update_jurisdictions taxonomy field. Jurisdiction
 * scoping uses the ws_jurisdiction taxonomy (save_terms=0 — terms
 * are selected for filtering purposes and not written to the taxonomy
 * table from this field).
 *
 * FUTURE USE
 * ----------
 * These records are intended for:
 *
 *      • internal legal tracking
 *      • journalist research
 *      • future public update feeds and timelines
 *
 * @package    WhistleblowerShield
 * @since      1.0.0
 * @author     Whistleblower Shield
 * @link       https://whistleblowershield.org
 * @copyright  Copyright (c) Whistleblower Shield
 *
 * VERSION
 * -------
 * 1.0.0  Initial release.
 * 2.1.0  Refactored for ws-core architecture. CPT slug corrected
 *         to ws-legal-update (hyphenated). File renamed from
 *         acf-legal-update.php to acf-ws-legal-update.php.
 *         Full header and inline comments added.
 * 3.1.1  Pass 2 ACF audit fix:
 *        - Added Content tab (field_legal_update_content_tab) before
 *          field_update_jurisdictions. All content fields now render
 *          inside a tab, consistent with all other CPT field groups.
 * 3.1.2  Pass 3 ACF audit — instructions fixes:
 *        - PURPOSE docblock: updated to remove reference to deleted
 *          admin-relationships.php; clarified ws_update_jurisdictions
 *          as a taxonomy field with save_terms=0.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'acf/init', 'ws_register_acf_legal_update' );

function ws_register_acf_legal_update() {

    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    acf_add_local_field_group( [

        'key'                   => 'group_legal_update_metadata',
        'title'                 => 'Legal Update Metadata',
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'active'                => true,

        // Location: ws-legal-update CPT only (hyphenated slug)
        'location' => [ [ [
            'param'    => 'post_type',
            'operator' => '==',
            'value'    => 'ws-legal-update',
        ] ] ],

        'fields' => [

            // ── Tab: Content ──────────────────────────────────────────────

            [
                'key'   => 'field_legal_update_content_tab',
                'label' => 'Content',
                'type'  => 'tab',
            ],

            // ── Affected Jurisdictions ────────────────────────────────────
			// Taxonomy multi-select — one update may affect many
			// jurisdictions. Scoped via ws_jurisdiction taxonomy terms.
			[
				'key'           => 'field_update_jurisdictions',
				'label'         => 'Affected Jurisdictions',
				'name'          => 'ws_update_jurisdictions',
				'type'          => 'taxonomy',
				'instructions'  => 'Select all jurisdictions affected by this legal update.',
				'taxonomy'      => 'ws_jurisdiction',
				'field_type'    => 'multi_select',
				'return_format' => 'id',
				'save_terms'    => 0,
				'load_terms'    => 0,
				'add_term'      => 0,
			],

            // ── Update Date ───────────────────────────────────────────────

            [
                'key'            => 'field_update_date',
                'label'          => 'Update Date',
                'name'           => 'ws_update_date',
                'type'           => 'date_picker',
                'instructions'   => 'Date the legal change took effect or was officially published.',
                'display_format' => 'F j, Y',
                'return_format'  => 'Y-m-d',
                'first_day'      => 1,
            ],

            // ── Primary Source ────────────────────────────────────────────

            [
                'key'          => 'field_ws_update_source',
                'label'        => 'Primary Source URL',
                'name'         => 'ws_update_source',
                'type'         => 'url',
                'instructions' => 'Official source for the legal change — e.g., court decision, statute, regulation, or agency policy document.',
            ],

            // ── Update Type ───────────────────────────────────────────────

            [
                'key'          => 'field_ws_update_type',
                'label'        => 'Update Type',
                'name'         => 'ws_update_type',
                'type'         => 'select',
                'instructions' => 'Select the category that best describes this legal development.',
                'choices'      => [
                    'statute'    => 'Statutory Change',
                    'court'      => 'Court Decision',
                    'regulation' => 'Regulatory Change',
                    'policy'     => 'Agency Policy',
                    'internal'   => 'Internal',
                    'other'      => 'Other',
                ],
                'default_value' => 'statute',
                'allow_null'    => 0,
                'ui'            => 1,
                'return_format' => 'value',
            ],

            // ── Law / Statute Name ────────────────────────────────────────

            [
                'key'          => 'field_ws_legal_update_law_name',
                'label'        => 'Law / Statute Name',
                'name'         => 'ws_legal_update_law_name',
                'type'         => 'text',
                'instructions' => 'The name of the law or statute affected by this update.',
            ],

            // ── Summary ───────────────────────────────────────────────────

            [
                'key'          => 'field_ws_legal_update_summary',
                'label'        => 'Summary',
                'name'         => 'ws_legal_update_summary',
                'type'         => 'wysiwyg',
                'instructions' => 'Brief summary of the legal change and its significance for whistleblowers.',
                'tabs'         => 'all',
                'toolbar'      => 'basic',
                'media_upload' => 0,
            ],

            // ── Effective Date ────────────────────────────────────────────

            [
                'key'            => 'field_ws_legal_update_effective_date',
                'label'          => 'Effective Date',
                'name'           => 'ws_legal_update_effective_date',
                'type'           => 'date_picker',
                'instructions'   => 'When does this change take effect? Leave blank if not yet determined.',
                'display_format' => 'F j, Y',
                'return_format'  => 'Y-m-d',
                'first_day'      => 1,
            ],

            // ── Tab: Authorship & Review ──────────────────────────────────

            [
                'key'   => 'field_authorship_tab',
                'label' => 'Authorship & Review',
                'type'  => 'tab',
            ],
            [
                'key'           => 'field_last_edited_author',
                'label'         => 'Last Edited By',
                'name'          => 'last_edited_author',
                'type'          => 'user',
                'instructions'  => 'Stamped automatically on every save. Editable by administrators only.',
                'role'          => [ 'author', 'editor', 'administrator' ],
                'return_format' => 'array',
                'wrapper'       => [ 'width' => '34' ],
            ],
            [
                'key'          => 'field_date_created',
                'label'        => 'Date Created',
                'name'         => 'date_created',
                'type'         => 'text',
                'instructions' => 'Set automatically on first save. Read only.',
                'readonly'     => 1,
                'disabled'     => 1,
                'wrapper'      => [ 'width' => '33' ],
            ],
            [
                'key'          => 'field_last_edited',
                'label'        => 'Last Edited',
                'name'         => 'last_edited',
                'type'         => 'text',
                'instructions' => 'Stamped automatically on every save. Read only.',
                'readonly'     => 1,
                'disabled'     => 1,
                'wrapper'      => [ 'width' => '33' ],
            ],
            [
                'key'           => 'field_create_author',
                'label'         => 'Created By',
                'name'          => 'create_author',
                'type'          => 'user',
                'instructions'  => 'Stamped automatically on first save. Read only.',
                'role'          => [ 'author', 'editor', 'administrator' ],
                'return_format' => 'id',
                'readonly'      => 1,
                'disabled'      => 1,
                'wrapper'       => [ 'width' => '33' ],
            ],

        ], // end fields

    ] ); // end acf_add_local_field_group

} // end ws_register_acf_legal_update
