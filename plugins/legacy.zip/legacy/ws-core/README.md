# WhistleblowerShield Core (ws-core)

**Version:** Legacy  
**Site:** https://whistleblowershield.org  
**Requires:** WordPress 6.0+, Advanced Custom Fields Pro  
**Enviroment:** PHP 8.2.30

## Overview

`ws-core` is the foundational plugin for WhistleblowerShield.org. It establishes the site's data architecture by registering specialized Custom Post Types (CPTs) and their associated metadata via Advanced Custom Fields (ACF) Pro. 

The plugin is designed with a **jurisdiction-centric data model**, where the primary legal data for a state, territory, or federal entity is linked to supplementary "addendum" records (Summaries, Statutes, Procedures, and Resources) through ACF relationship fields.

## Core Components

### 1. Data Structure (CPTs)
The plugin registers the following post types to manage legal and jurisdictional data:
* **Jurisdictions:** The primary entry for each legal entity (e.g., California, U.S. Federal).
* **Summaries (`jx-summary`):** High-level legal protection overviews linked to a jurisdiction.
* **Statutes (`jx-statutes`):** Records of specific laws, citations, and effective dates.
* **Procedures (`jx-procedures`):** Step-by-step reporting instructions and agency contacts.
* **Resources (`jx-resources`):** External advocacy groups, legal aid, and government agencies.
* **Legal Updates (`ws-legal-update`):** A timestamped log of significant legal changes.

### 2. Field Groups (ACF Pro)
Each CPT is extended with structured field groups to ensure data integrity across the site. Key fields include:
* **Identity & Metadata:** Flag imagery, official names, and jurisdiction classifications.
* **Connectivity:** URLs for government portals, legal authorities, and official guidance.
* **Relationships:** Bi-directional links between the main Jurisdiction and its addendum components.
* **Authorship:** User-selectable author credits and legal review status tracking.

### 3. Public-Facing Tools
* **Shortcodes:** A library of shortcodes for rendering jurisdiction headers, flags, legal summaries, and the global jurisdictional index with interactive type-filtering.
* **Styles:** A minimal frontend stylesheet (`ws-core-front.css`) that manages the layout of shortcode output, badges, and tooltips.

### 4. Integrity & Auditing
The plugin includes a background **Audit Trail** system. Every time a `ws-core` post is saved, the system captures the User ID and a UTC timestamp in a hidden, append-only history log within the post metadata. This ensures a tamper-resistant record of all editorial changes.

## Integration
This plugin is a required dependency for the WhistleblowerShield ecosystem. It must be active for any jurisdiction-specific content or legal updates to render correctly.