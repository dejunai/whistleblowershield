<?php
/**
 * acf-statutes.php
 *
 * Registers the ACF Pro field group for the `jx-statutes` CPT.
 *
 * The jx-statutes CPT represents formal statutes or laws that apply
 * within a jurisdiction — e.g., the False Claims Act (U.S. Federal)
 * or California Labor Code § 1102.5.
 *
 * Each statute record attaches to a parent jurisdiction via an ACF
 * relationship field, consistent with the jurisdiction-centric data model
 * used throughout ws-core.
 *
 * Fields registered:
 *   ws_statute_jurisdiction  (Relationship → jurisdiction, required)
 *   ws_statute_name          (Text, required)
 *   ws_statute_citation      (Text, required)
 *   ws_statute_type          (Select: federal_statute | state_statute |
 *                             federal_regulation | state_regulation |
 *                             executive_order | other)
 *   ws_statute_official_source (URL — link to govinfo.gov, congress.gov, etc.)
 *   ws_statute_effective_date  (Date Picker)
 *   ws_statute_notes           (Textarea — internal commentary only)
 *   ws_statute_post_author     (User - selectable, defaults to current user)
 *
 * Citation format guidance follows the U.S. Legal Citation Model documented
 * in documentation/architecture/legal-citation-model.md.
 *
 * Added in v2.0.0. The jx-statutes CPT was registered in v1.8.0 but had
 * no ACF field group until this release.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'acf/init', 'ws_register_acf_statute_fields' );
function ws_register_acf_statute_fields() {

    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    acf_add_local_field_group( [
        'key'      => 'group_ws_statute',
        'title'    => 'Statute Details',
        'location' => [ [ [
            'param'    => 'post_type',
            'operator' => '==',
            'value'    => 'jx-statutes',
        ] ] ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'fields' => [

            // ── Jurisdiction ──────────────────────────────────────────────

            [
                'key'          => 'field_ws_statute_jurisdiction',
                'label'        => 'Jurisdiction',
                'name'         => 'ws_statute_jurisdiction',
                'type'         => 'relationship',
                'instructions' => 'Select the jurisdiction where this statute applies. Every statute must reference a jurisdiction.',
                'required'     => 1,
                'post_type'    => [ 'jurisdiction' ],
                'filters'      => [ 'search' ],
                'max'          => 1,
                'return_format' => 'object',
            ],

            // ── Statute Name ──────────────────────────────────────────────

            [
                'key'          => 'field_ws_statute_name',
                'label'        => 'Statute Name',
                'name'         => 'ws_statute_name',
                'type'         => 'text',
                'instructions' => 'Official name of the statute or regulation — e.g., False Claims Act, Dodd-Frank Wall Street Reform and Consumer Protection Act, California Labor Code § 1102.5. Use the full official name; do not abbreviate.',
                'required'     => 1,
            ],

            // ── Citation ──────────────────────────────────────────────────

            [
                'key'          => 'field_ws_statute_citation',
                'label'        => 'Legal Citation',
                'name'         => 'ws_statute_citation',
                'type'         => 'text',
                'instructions' => 'Formatted legal citation following standard U.S. citation conventions. Federal statutes: "31 U.S.C. § 3729". Federal regulations: "17 C.F.R. § 240.21F-2". State statutes: "Cal. Lab. Code § 1102.5". Required.',
                'required'     => 1,
                'placeholder'  => 'e.g., 31 U.S.C. § 3729',
            ],

            // ── Statute Type ──────────────────────────────────────────────

            [
                'key'          => 'field_ws_statute_type',
                'label'        => 'Statute Type',
                'name'         => 'ws_statute_type',
                'type'         => 'select',
                'instructions' => 'Select the type of legal authority this record represents.',
                'required'     => 1,
                'choices'      => [
                    'federal_statute'    => 'Federal Statute (U.S.C.)',
                    'state_statute'      => 'State Statute',
                    'federal_regulation' => 'Federal Regulation (C.F.R.)',
                    'state_regulation'   => 'State Regulation',
                    'executive_order'    => 'Executive Order',
                    'other'              => 'Other',
                ],
                'default_value' => 'state_statute',
                'allow_null'    => 0,
                'ui'            => 1,
            ],

            // ── Official Source URL ───────────────────────────────────────

            [
                'key'          => 'field_ws_statute_official_source',
                'label'        => 'Official Source URL',
                'name'         => 'ws_statute_official_source',
                'type'         => 'url',
                'instructions' => 'Link to the official text of this statute. Preferred sources: govinfo.gov, congress.gov, federalregister.gov, or the official state legislature website. Do not link to secondary sources when a primary source is available.',
                'placeholder'  => 'https://www.govinfo.gov/...',
            ],

            // ── Effective Date ────────────────────────────────────────────

            [
                'key'          => 'field_ws_statute_effective_date',
                'label'        => 'Effective Date',
                'name'         => 'ws_statute_effective_date',
                'type'         => 'date_picker',
                'instructions' => 'The date this statute or regulation came into effect. Leave blank if the effective date is unclear or not applicable.',
                'display_format' => 'F j, Y',
                'return_format'  => 'Y-m-d',
                'first_day'      => 0,
            ],

            // ── Internal Notes ────────────────────────────────────────────

            [
                'key'          => 'field_ws_statute_notes',
                'label'        => 'Internal Notes',
                'name'         => 'ws_statute_notes',
                'type'         => 'textarea',
                'instructions' => 'Internal editorial notes about this statute — not displayed publicly. Use to document research sources, outstanding questions, or review status notes.',
                'rows'         => 4,
            ],
			
			// ── Post Author ─────────────────────────────────────────

            [
                'key'          => 'field_ws_statute_post_author',
                'label'        => 'Post Author',
                'name'         => 'ws_statute_post_author',
                'type'         => 'user',
                'instructions' => 'Credited author displayed on the front end. Defaults to the current user. May be changed to any registered user with Author role or above.',
                'role'         => [ 'author', 'editor', 'administrator' ],
                'allow_null'   => 0,
                'multiple'     => 0,
                'return_format' => 'array',
            ],

        ], // end fields
    ] ); // end acf_add_local_field_group
}
// ── Auto-fill: ws_statute_post_author (current user, new posts only) ───────────────────────

add_filter( 'acf/load_value/name=ws_statute_post_author', 'ws_autofill_statute_post_author', 10, 3 );
function ws_autofill_statute_post_author( $value, $post_id, $field ) {
    if ( empty( $value ) ) {
        $value = get_current_user_id();
    }
    return $value;
}
