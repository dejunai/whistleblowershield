﻿# CPT Relationship Map

## Purpose

This document defines the relationships between the Custom Post Types
used by the ws-core plugin.

The goal is to ensure that legal data is structured consistently and
that all entities connect through a clear jurisdiction model.

---

# Core Entity

The root entity in the system is the **Jurisdiction**.

Every legal object in the system must connect to a jurisdiction.

Example:

Jurisdiction
 ├ Summary
 ├ Statutes
 ├ Procedures
 ├ Resources
 └ Legal Updates

---

# Custom Post Types

## jurisdiction

Represents a legal authority.

Examples:

United States  
California  
European Union

Fields:

- name
- region
- governing body
- notes

Relationships:

- has many summaries
- has many statutes
- has many procedures
- has many resources
- has many legal updates

---

## jx-summary

Human-readable explanation of whistleblower law
in a jurisdiction.

Relationships:

jx-summary → jurisdiction

Purpose:

Provides the primary overview page for the jurisdiction.

---

## jx-statute

Represents a legal statute or law.

Examples:

False Claims Act  
Sarbanes-Oxley Act

Relationships:

jx-statute → jurisdiction

Fields:

- statute name
- citation
- official source
- notes

---

## jx-procedure

Describes how a whistleblower can report violations.

Examples:

SEC reporting procedure  
OSHA complaint procedure

Relationships:

jx-procedure → jurisdiction

Fields:

- reporting agency
- process description
- official guidance links

---

## jx-resource

External resource relevant to whistleblowers.

Examples:

advocacy organizations  
legal assistance resources  
government guidance

Relationships:

jx-resource → jurisdiction

---

## ws-legal-update

Represents a change in law or policy.

Examples:

new statute passed  
court interpretation  
agency rule change

Relationships:

ws-legal-update → jurisdiction

Fields:

- law name
- summary
- source URL
- effective date

---

# Relationship Overview

jurisdiction
 ├ jx-summary
 ├ jx-statute
 ├ jx-procedure
 ├ jx-resource
 └ ws-legal-update

All entities reference a jurisdiction using ACF relationship fields.

---

# Future Extensions

Possible future CPTs:

case-law  
regulatory-agency  
enforcement-action  
legal-commentary

These would also attach to jurisdictions.

---

# Design Principles

1. Jurisdiction is always the root entity
2. All legal data must attach to a jurisdiction
3. Relationships must be explicit
4. No orphan legal entities should exist